package com.capgemini.springmvc.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.springmvc.dto.EmployeeBean;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	Connection con = null;
	PreparedStatement prepstmt = null;
	ResultSet rs = null;
	EmployeeBean employeeBean = null;

	String dbUrl = "jdbc:mysql://localhost:3306/emp";
	String user = "Anu";
	String pass = "9SreeRama9@1";

	public EmployeeBean getEmployeeByid(int empId) {

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("select * from empinfo where empId=?");
			prepstmt.setInt(1, empId);
			rs = prepstmt.executeQuery();
			if (rs.next()) {
				employeeBean = new EmployeeBean();
				employeeBean.setEmpId(rs.getInt("empId"));
				employeeBean.setAge(rs.getInt("age"));
				employeeBean.setEmpName(rs.getString("empName"));
				employeeBean.setDesignation(rs.getString("designation"));
				employeeBean.setPassword(rs.getString("password"));
				employeeBean.setSalary(rs.getDouble("salary"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (prepstmt != null) {
				try {
					prepstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return employeeBean;
	}

	public boolean addEmployee(EmployeeBean bean) {
		String query1 = "insert into empinfo values(?,?,?,?,?,?)";
		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement(query1);
			prepstmt.setInt(1, bean.getEmpId());
			prepstmt.setString(2, bean.getEmpName());
			prepstmt.setInt(3, bean.getAge());
			prepstmt.setDouble(4, bean.getSalary());
			prepstmt.setString(5, bean.getDesignation());
			prepstmt.setString(6, bean.getPassword());
			int result = prepstmt.executeUpdate();
			if (result != 0) {
				System.out.println("values are inserted succefully");
				return true;
			}
			con.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return false;
	}

	public boolean updateEmployee(EmployeeBean bean) {
		boolean isUpdated = false;
		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("update empinfo set empname=? where empid=? ");
			prepstmt.setString(1, bean.getEmpName());
			prepstmt.setInt(2, bean.getEmpId());
			int result = prepstmt.executeUpdate();
			if (result > 0) {
				System.out.println("values are updated succefully");
				isUpdated = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return isUpdated;
	}

	public boolean deleteEmployee(int empId) {
		boolean isDeleted = false;
		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("delete from  empinfo  where empId=?");
			prepstmt.setInt(1, empId);
			int result = prepstmt.executeUpdate();
			if (result > 0) {
				System.out.println("values deleted succefully");
				isDeleted = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return isDeleted;
	}

	public List<EmployeeBean> getAllEmployees() {
		List<EmployeeBean> listInfo = new ArrayList<EmployeeBean>();

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("select * from empinfo");
			rs = prepstmt.executeQuery();

			while (rs.next()) {
				EmployeeBean bean = new EmployeeBean();

				bean.setEmpName(rs.getString("empName"));
				bean.setAge(rs.getInt("age"));
				bean.setPassword(rs.getString("password"));
				bean.setDesignation(rs.getString("designation"));
				bean.setSalary(rs.getDouble("salary"));
				bean.setEmpId(rs.getInt("empId"));

				listInfo.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return listInfo;
	}
	public EmployeeBean authenticate(int empId, String password) {
		EmployeeBean employeeBean = getEmployeeByid(empId);
		if (!(employeeBean != null && employeeBean.getPassword().equals(password))) {
			employeeBean = null;
		}
		return null;
	}
}
