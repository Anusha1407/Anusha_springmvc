package com.capgemini.springmvc.dto;

import java.io.Serializable;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class EmployeeBean implements Serializable {
	private int empId;
	private String empName;
	private int age;
	private double salary;
	private String designation;
	private String password;

}
